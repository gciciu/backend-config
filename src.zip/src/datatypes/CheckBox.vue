<template>
    <div id="sm__checkbox">
        CheckBox
    </div>
</template>

<script>
  export default {
    name: 'CheckBox',
    components: {

    }
  }
</script>

<style>

</style>
