<template>
    <div id="sm__email">
        Email
    </div>
</template>

<script>
  export default {
    name: 'Email',
    components: {

    }
  }
</script>

<style>

</style>
