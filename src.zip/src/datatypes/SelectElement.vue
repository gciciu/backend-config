<template>
  <tr id="r1">
    <td><input name="item[]" type="text"/></td>
    <td><input name="quantity[]" type="number"/></td>
    <td><button class="deleteRow">X</button></td>
  </tr>
</template>

<script>
export default {
  name: 'SelectElement',

}
</script>

<style scoped>

</style>
