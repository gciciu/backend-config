<template>
    <div id="sm__share">
        Share
    </div>
</template>

<script>
  export default {
    name: 'Share',
    components: {

    }
  }
</script>

<style>

</style>
