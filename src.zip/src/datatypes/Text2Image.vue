<template>
    <div id="sm__text2image">
        Text2Image
    </div>
</template>

<script>
  export default {
    name: 'Text2Image',
    components: {

    }
  }
</script>

<style>

</style>
