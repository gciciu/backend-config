<template>
    <div id="sm__expression">
        Expression
    </div>
</template>

<script>
  export default {
    name: 'Expression',
    components: {

    }
  }
</script>

<style>

</style>
