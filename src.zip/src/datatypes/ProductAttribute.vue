<template>
    <div id="sm__productattribute">
        ProductAttribute
    </div>
</template>

<script>
  export default {
    name: 'ProductAttribute',
    components: {

    }
  }
</script>

<style>

</style>
