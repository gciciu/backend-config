<template>
    <div id="sm__textarea">
        TextArea
    </div>
</template>

<script>
  export default {
    name: 'TextArea',
    components: {

    }
  }
</script>

<style>

</style>
