<template>
    <div id="sm__text">
        Title : <input type="input" id="titel">
        <br />
        Pflichtfeld: <input type="radio" id="yes" value="Yes"><label for="yes">Ja</label>
                     <input type="radio" id="no" value="No" ><label for="no">Nein</label>
    </div>
</template>

<script>
  export default {
    name: 'TextField',
    components: {

    }
  }
</script>

<style>

</style>
