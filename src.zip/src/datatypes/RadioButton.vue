<template>
    <div id="sm__radiobutton">
        RadioButton
    </div>
</template>

<script>
  export default {
    name: 'RadioButton',
    components: {

    }
  }
</script>

<style>

</style>
