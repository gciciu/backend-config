<template>
    <div id="sm__matrix">
        Matrix
    </div>
</template>

<script>
  export default {
    name: 'Matrix',
    components: {

    }
  }
</script>

<style>

</style>
