<template>
    <div id="sm__combinedimage">
        CombinedImage
    </div>
</template>

<script>
  export default {
    name: 'CombinedImage',
    components: {

    }
  }
</script>

<style>

</style>
