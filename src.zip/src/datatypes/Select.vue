<template>
    <div id="sm__select">
        Select {{ product.name }}
    </div>
</template>

<script>
  export default {
    props: ['products'],
    data () {
      return {
      }
    }
  }
</script>

<style>

</style>
